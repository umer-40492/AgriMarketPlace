// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBGcm-C7k2RueCLpJBvfDqP_T6OZYMmnMo",
    authDomain: "agri-marketplace-6279f.firebaseapp.com",
    databaseURL: "https://agri-marketplace-6279f-default-rtdb.firebaseio.com",
    projectId: "agri-marketplace-6279f",
    storageBucket: "agri-marketplace-6279f.appspot.com",
    messagingSenderId: "79846147719",
    appId: "1:79846147719:web:4a9d30931fb761c2589a22"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
