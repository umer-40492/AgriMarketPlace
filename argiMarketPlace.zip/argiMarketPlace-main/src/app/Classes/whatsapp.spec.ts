import { Whatsapp } from './whatsapp';

describe('Whatsapp', () => {
  it('should create an instance', () => {
    expect(new Whatsapp()).toBeTruthy();
  });
});
