import { NewsLetter } from './news-letter';

describe('NewsLetter', () => {
  it('should create an instance', () => {
    expect(new NewsLetter()).toBeTruthy();
  });
});
